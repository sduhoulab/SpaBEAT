import sys
sys.path.insert(0, '/data_hou/BE/SPIRAL')

import os
import gc
import time
import json
import psutil
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import anndata
import scanpy as sc
import argparse
from sklearn.decomposition import PCA
from operator import itemgetter
import random
import matplotlib.pyplot as plt
import umap.umap_ as umap

if 'spiral' in sys.modules:
    del sys.modules['spiral']

import spiral

print("spiral path:")
print(spiral.__file__)


from spiral.main import SPIRAL_integration
from spiral.layers import *
from spiral.utils import *
from spiral.CoordAlignment import CoordAlignment
from warnings import filterwarnings
filterwarnings("ignore")
from sklearn.neighbors import NearestNeighbors

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

def get_memory_usage():
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 / 1024

# =============== Configuration and Data Setup ===============
input_dir="/data_hou/ZhaoMH/data/stereo_embryo/Embryo_converted/"
results_dir="/data_hou/ZhaoMH/new_model/Spiral/results/"
datasets=np.array(['Slice_5', 'Slice_6', 'Slice_7', 'Slice_8', 'Slice_9'])
SEP=','
net_cate='_KNN_'
rad=150
knn=8
type_name = 'GNN_format'

N_WALKS=knn
WALK_LEN=1
N_WALK_LEN=knn
NUM_NEG=knn

feat_file=[]
edge_file=[]
meta_file=[]
coord_file=[]

for dataset in datasets:
    base_path = f"{input_dir}{dataset}/GNN_format/"
   
    feat_file.append(f"{base_path}{dataset}_features.txt")
    edge_file.append(f"{base_path}{dataset}_edge_KNN_{knn}.csv")
    meta_file.append(f"{base_path}{dataset}_label.txt")
    coord_file.append(f"{base_path}{dataset}_positions.txt")

print("Aligning and formatting input files securely...")
dfs = []
for f_path in feat_file:
    df = pd.read_csv(f_path, sep=None, index_col=0)
    df.index = df.index.astype(str).str.strip()
    df.columns = df.columns.astype(str).str.strip()
    dfs.append(df)

common_genes = set(dfs[0].columns)
for df in dfs[1:]:
    common_genes = common_genes.intersection(set(df.columns))

common_genes = sorted(list(common_genes))

print("\n===== GENE INTERSECTION =====")
print("Common genes:", len(common_genes))

new_feat_files = []
for i, df in enumerate(dfs):
    df_common = df.loc[:, common_genes]
    print(f"{datasets[i]} unified shape:", df_common.shape)
    new_file = feat_file[i].replace("_features.txt", "_features_common.txt")
    df_common.to_csv(new_file, sep=',')
    new_feat_files.append(new_file)

feat_file = new_feat_files
N = len(common_genes)

print("Final feature dimension:", N)

N = pd.read_csv(feat_file[0], header=0, index_col=0).shape[1]
M = 1 if len(datasets) == 2 else len(datasets)

total_cells = 0
for feat in feat_file:
    df = pd.read_csv(feat, header=0, index_col=0)
    total_cells += df.shape[0]

print(f"Total cells to process: {total_cells:,}")
print(f"Total genes: {N:,}")
print(f"Number of datasets: {len(datasets)}")

parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=0, help='The seed of initialization.')
parser.add_argument('--AEdims', type=list, default=[N,[512],32], help='Dim of encoder.')
parser.add_argument('--AEdimsR', type=list, default=[32,[512],N], help='Dim of decoder.')
parser.add_argument('--GSdims', type=list, default=[512,32], help='Dim of GraphSAGE.')
parser.add_argument('--zdim', type=int, default=32, help='Dim of embedding.')
parser.add_argument('--znoise_dim', type=int, default=4, help='Dim of noise embedding.')
parser.add_argument('--CLdims', type=list, default=[4,[],M], help='Dim of classifier.')
parser.add_argument('--DIdims', type=list, default=[28,[32,16],M], help='Dim of discriminator.')
parser.add_argument('--beta', type=float, default=1.0, help='weight of GraphSAGE.')
parser.add_argument('--agg_class', type=str, default=MeanAggregator, help='Function of aggregator.')
parser.add_argument('--num_samples', type=str, default=knn, help='number of neighbors to sample.')

parser.add_argument('--N_WALKS', type=int, default=N_WALKS, help='number of walks of random work for postive pairs.')
parser.add_argument('--WALK_LEN', type=int, default=WALK_LEN, help='walk length of random work for postive pairs.')
parser.add_argument('--N_WALK_LEN', type=int, default=N_WALK_LEN, help='number of walks of random work for negative pairs.')
parser.add_argument('--NUM_NEG', type=int, default=NUM_NEG, help='number of negative pairs.')

parser.add_argument('--epochs', type=int, default=100, help='Number of epochs to train.')
parser.add_argument('--batch_size', type=int, default=1024, help='Size of batches to train.') ####512 for withon donor;1024 for across donor###
parser.add_argument('--lr', type=float, default=1e-3, help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4, help='Weight decay.')
parser.add_argument('--alpha1', type=float, default=N, help='Weight of decoder loss.')
parser.add_argument('--alpha2', type=float, default=1, help='Weight of GraphSAGE loss.')
parser.add_argument('--alpha3', type=float, default=1, help='Weight of classifier loss.')
parser.add_argument('--alpha4', type=float, default=1, help='Weight of discriminator loss.')
parser.add_argument('--lamda', type=float, default=1, help='Weight of GRL.')
parser.add_argument('--Q', type=float, default=10, help='Weight negative loss for sage losss.')

params,unknown=parser.parse_known_args()

# =============== SPIRAL Training with Benchmarking ===============
print("Starting SPIRAL training benchmarking...")

# Clear memory before training for fair comparison
gc.collect()
torch.cuda.empty_cache()

memory_before = get_memory_usage()
training_start_time = time.time()

print("Training SPIRAL model...")
SPII=SPIRAL_integration(params,feat_file,edge_file,meta_file)
print("\n===== FEATURE DEBUG =====")

print("SPII.feat shape:", SPII.feat.shape)

for i, f in enumerate(feat_file):
    tmp = pd.read_csv(f, header=0, index_col=0)

    print(f"\nDataset {datasets[i]}")
    print("shape:", tmp.shape)

    print("first 5 genes:")
    print(tmp.columns[:5].tolist())

    print("last 5 genes:")
    print(tmp.columns[-5:].tolist())
    
print("\n===== NODE CHECK =====")

for i in range(len(feat_file)):

    feat_df = pd.read_csv(feat_file[i], header=0, index_col=0)
    edge_df = pd.read_csv(edge_file[i], header=None)
    print(f"\n{datasets[i]}")
    print("feature cells:", feat_df.shape[0])
    print("max edge idx:", edge_df.values.max())
    print("min edge idx:", edge_df.values.min())
    
print("\n===== FEATURE / EDGE MATCH CHECK =====")

for i in range(len(feat_file)):

    feat_df = pd.read_csv(
        feat_file[i],
        header=0,
        index_col=0
    )

    edge_df = pd.read_csv(
        edge_file[i],
        sep=None,
        engine='python'
    )

    feature_nodes = set(feat_df.index)

    edge_nodes = set(edge_df.iloc[:,0]).union(
        set(edge_df.iloc[:,1])
    )

    missing_nodes = edge_nodes - feature_nodes

    print(f"\n{datasets[i]}")

    print("feature cells:", len(feature_nodes))
    print("edge nodes:", len(edge_nodes))

    print("missing nodes:", len(missing_nodes))

    if len(missing_nodes) > 0:
        print("example missing:")
        print(list(missing_nodes)[:10])
        
          
SPII.train()

training_end_time = time.time()
training_time = training_end_time - training_start_time
memory_after = get_memory_usage()
memory_used = memory_after - memory_before

print("Training completed!")

dataset_str = '_'.join(datasets.tolist())

model_file = os.path.join(
    results_dir,
    "model",
    f"SPIRAL_embed_{SPII.params.batch_size}_{dataset_str}.pt"
)

os.makedirs(os.path.dirname(model_file), exist_ok=True)
torch.save(SPII.model.state_dict(), model_file)

SPII.model.eval()
all_idx=np.arange(SPII.feat.shape[0])
all_layer,all_mapping=layer_map(all_idx.tolist(),SPII.adj,len(SPII.params.GSdims))
all_rows=SPII.adj.tolil().rows[all_layer[0]]
all_feature=torch.Tensor(SPII.feat.iloc[all_layer[0],:].values).float().cuda()

all_embed,ae_out,clas_out,disc_out=SPII.model(all_feature,all_layer,all_mapping,all_rows,SPII.params.lamda,SPII.de_act,SPII.cl_act)
[ae_embed,gs_embed,embed]=all_embed
[x_bar,x]=ae_out

embed=embed.cpu().detach()
names=['GTT_'+str(i) for i in range(embed.shape[1])]
embed1=pd.DataFrame(np.array(embed),index=SPII.feat.index,columns=names)

embed_dir = os.path.join(results_dir, "gtt_output")
os.makedirs(embed_dir, exist_ok=True)

embed_file = os.path.join(embed_dir, f"SPIRAL_embed_{SPII.params.batch_size}_{dataset_str}.csv")
embed1.to_csv(embed_file)

meta=SPII.meta.values
embed_df = pd.DataFrame(embed.cpu().detach().numpy(), index=SPII.feat.index)
znoise_dim = SPII.params.znoise_dim
embed_new_df = pd.concat([
    pd.DataFrame(np.zeros((embed_df.shape[0], znoise_dim)), index=embed_df.index),
    embed_df.iloc[:, znoise_dim:]
], axis=1)
embed_new = torch.tensor(embed_new_df.values).float().cuda()
xbar_new=np.array(SPII.model.agc.ae.de(embed_new.cuda(),nn.Sigmoid())[1].cpu().detach())
xbar_new1=pd.DataFrame(xbar_new,index=SPII.feat.index,columns=SPII.feat.columns)

xbar_file = os.path.join(embed_dir, f"SPIRAL_correct_{SPII.params.batch_size}_{dataset_str}.csv")
xbar_new1.to_csv(xbar_file)


# =============== Save Benchmark Results ===============
benchmark_results = {
    'method_name': 'SPIRAL',
    'training_time_seconds': training_time,
    'training_time_minutes': training_time / 60,
    'training_time_hours': training_time / 3600,
    'memory_usage_mb': memory_used,
    'memory_usage_gb': memory_used / 1024,
    'total_cells': total_cells,
    'final_cells': SPII.feat.shape[0],
    'total_genes': N,
    'embedding_dim': embed.shape[1],
    'n_datasets': len(datasets),
    'epochs': params.epochs,
    'timestamp': pd.Timestamp.now().isoformat()
}

# Save benchmark results
if not os.path.exists(results_dir):
    os.makedirs(results_dir)

with open(os.path.join(results_dir, "spiral_benchmark_embryo.json"), "w") as f:
    json.dump(benchmark_results, f, indent=2)

# =============== Clustering and Analysis ===============
print("Performing clustering analysis...")

ann=anndata.AnnData(SPII.feat)
ann.obsm['spiral']=embed1.iloc[:,SPII.params.znoise_dim:].values
sc.pp.neighbors(ann,use_rep='spiral')

n_clust=25

ann = mclust_R(ann, used_obsm='spiral', num_cluster=n_clust)
ann.X=SPII.feat
ann.obs['batch']=SPII.meta.loc[:,'batch'].values
ann.obs['celltype']=SPII.meta.loc[:,'celltype'].values
ub=np.unique(ann.obs['batch'])

coord = pd.read_csv(coord_file[0], header=0, index_col=0)
print(coord.head())
for i in np.arange(1, len(datasets)):
    coord = pd.concat((coord, pd.read_csv(coord_file[i], header=0, index_col=0)))

coord.columns = ['y', 'x']
if len(coord) == ann.n_obs:
    ann.obsm['spatial'] = coord.values
    print(f"Successfully loaded {len(coord)} coordinates into the AnnData object.")
else:
    raise ValueError(f"Length mismatch! Coordinate table contains {len(coord)} rows, while AnnData has {ann.n_obs} cells. Please check missing data.")
    
# ann.obsm['spatial'] = coord.loc[ann.obs_names, :].values
ann.obs["new_batch"] = ann.obs["batch"].astype(str)
ann.write('/data_hou/ZhaoMH/new_model/Spiral/results/spiral_embryo.h5ad')


# Clean up memory after processing
gc.collect()
torch.cuda.empty_cache()

final_memory = get_memory_usage()
print(f"Final memory usage: {final_memory:.1f} MB")
